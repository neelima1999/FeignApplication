package com.main.entity;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "products")

public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "product_name")
	@NotNull
	@NotNull(message = "productName is required")
	@Size(min = 3, max = 20, message = "name should contain atleast 3 letters")
	private String productName;

	@Column(name = "price")
	@NotNull(message = "price should not be empty")
	private int price;

	@Column(name = "discription")
	@NotNull(message = "discription should not be empty")
	private String discription;

	@Column(name = "category")
	@NotNull(message = "category should not be empty")
	private String category;

	@Column(name = "availability")
	@NotNull(message = "availability should not be empty")
	private int availability;

	public Product() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getDiscription() {
		return discription;
	}

	public void setDiscription(String discription) {
		this.discription = discription;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getAvailability() {
		return availability;
	}

	public void setAvailability(int availability) {
		this.availability = availability;
	}
}
